import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Code2, 
  Webhook, 
  Copy, 
  Check, 
  Play, 
  CheckCircle2, 
  ExternalLink,
  Lock,
  Layers
} from 'lucide-react';
import { Campaign } from '../types/growth';

interface IntegrationPanelProps {
  campaign: Campaign;
  onRefreshCampaign: () => void;
}

export const IntegrationPanel: React.FC<IntegrationPanelProps> = ({
  campaign,
  onRefreshCampaign,
}) => {
  const [activeTab, setActiveTab] = useState<'pixel' | 'webhook'>('pixel');
  const [copiedPixel, setCopiedPixel] = useState(false);
  const [copiedWebhook, setCopiedWebhook] = useState(false);
  const [copiedCurl, setCopiedCurl] = useState(false);
  
  // Webhook tester state
  const [testEmail, setTestEmail] = useState('nuevo.usuario@empresa.com');
  const [testReferrer, setTestReferrer] = useState('https://google.com/search');
  const [testingWebhook, setTestingWebhook] = useState(false);
  const [webhookResult, setWebhookResult] = useState<any>(null);

  // Pixel tester state
  const [testingPixel, setTestingPixel] = useState(false);
  const [pixelResult, setPixelResult] = useState<any>(null);

  const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const pixelScriptUrl = `${baseUrl}/api/pixel/${campaign.id}.js`;
  const webhookUrl = `${baseUrl}/api/webhook/conversion/${campaign.id}`;

  const pixelSnippet = `<!-- KaSe - Marketing Digital: Píxel de Seguimiento de Conversión -->
<!-- Pegar este script en la página de "Registro Exitoso" (Thank You Page) -->
<script src="${pixelScriptUrl}" async></script>`;

  const curlSnippet = `curl -X POST "${webhookUrl}" \\
  -H "Content-Type: application/json" \\
  -H "x-kase-secret: ${campaign.webhookSecret}" \\
  -d '{
    "userId": "usr_109283",
    "email": "${testEmail}",
    "referrer": "${testReferrer}"
  }'`;

  const nodeSnippet = `// Node.js / Express Backend Example
const trackConversion = async (userData) => {
  const response = await fetch('${webhookUrl}', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-kase-secret': '${campaign.webhookSecret}'
    },
    body: JSON.stringify({
      userId: userData.id,
      email: userData.email,
      referrer: req.headers['referer'] || 'direct'
    })
  });
  const data = await response.json();
  console.log('[KaSe] Registro contabilizado:', data);
};`;

  const pythonSnippet = `# Python / Django / FastAPI Backend Example
import requests

def track_conversion(user_id, email):
    url = "${webhookUrl}"
    headers = {
        "Content-Type": "application/json",
        "x-kase-secret": "${campaign.webhookSecret}"
    }
    payload = {
        "userId": user_id,
        "email": email,
        "referrer": "checkout_flow"
    }
    response = requests.post(url, json=payload)
    return response.json()`;

  const handleCopy = (text: string, type: 'pixel' | 'webhook' | 'curl') => {
    navigator.clipboard.writeText(text);
    if (type === 'pixel') {
      setCopiedPixel(true);
      setTimeout(() => setCopiedPixel(false), 2000);
    } else if (type === 'webhook') {
      setCopiedWebhook(true);
      setTimeout(() => setCopiedWebhook(false), 2000);
    } else {
      setCopiedCurl(true);
      setTimeout(() => setCopiedCurl(false), 2000);
    }
  };

  const handleTestWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    setTestingWebhook(true);
    setWebhookResult(null);

    try {
      const res = await fetch(`/api/webhook/conversion/${campaign.id}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-kase-secret': campaign.webhookSecret,
        },
        body: JSON.stringify({
          email: testEmail,
          referrer: testReferrer,
        }),
      });

      const data = await res.json();
      setWebhookResult(data);
      onRefreshCampaign();
    } catch (err: any) {
      setWebhookResult({ error: err.message || 'Error al conectar con webhook' });
    } finally {
      setTestingWebhook(false);
    }
  };

  const handleTestPixel = async () => {
    setTestingPixel(true);
    setPixelResult(null);

    try {
      const res = await fetch(`/api/pixel/conversion/${campaign.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          referrer: 'Simulador de Prueba de Píxel en Vivo',
        }),
      });

      const data = await res.json();
      setPixelResult(data);
      onRefreshCampaign();
    } catch (err: any) {
      setPixelResult({ error: err.message || 'Error al disparar píxel' });
    } finally {
      setTestingPixel(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. Header with Security Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Centro de Integración 100% Segura
          </h2>
          <p className="text-xs text-neutral-400 mt-1 max-w-2xl leading-relaxed">
            Arquitectura externa sin fricciones: KaSe nunca solicitará contraseñas, bases de datos internas ni APIs de producción de tu aplicación.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-lg">
          <ShieldCheck className="w-4 h-4" />
          <span>Zero-Access Security Verified</span>
        </div>
      </div>

      {/* 2. Three-Step Visual Architecture */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#161616] border border-neutral-800 rounded-xl p-4 space-y-2">
          <div className="text-xs font-mono text-neutral-400 font-semibold">PASO 01</div>
          <div className="text-sm font-bold text-white">Formulario Externo</div>
          <p className="text-xs text-neutral-400 leading-relaxed">
            Solo ingresas el nombre, URL de destino y la meta de usuarios registrados que deseas conseguir.
          </p>
        </div>

        <div className="bg-[#161616] border border-neutral-800 rounded-xl p-4 space-y-2">
          <div className="text-xs font-mono text-emerald-400 font-semibold">PASO 02</div>
          <div className="text-sm font-bold text-white">Generación de Token</div>
          <p className="text-xs text-neutral-400 leading-relaxed">
            KaSe genera automáticamente un Script de Píxel y un Endpoint de Webhook único y cifrado para la campaña.
          </p>
        </div>

        <div className="bg-[#161616] border border-neutral-800 rounded-xl p-4 space-y-2">
          <div className="text-xs font-mono text-sky-400 font-semibold">PASO 03</div>
          <div className="text-sm font-bold text-white">Contabilización & Auto-Pausa</div>
          <p className="text-xs text-neutral-400 leading-relaxed">
            Pega el script en tu "Thank You Page" o haz un POST desde tu servidor. Al llegar al tope, el sistema se pausa solo.
          </p>
        </div>
      </div>

      {/* 3. Method Tabs (Interactive Controls) */}
      <div className="flex items-center gap-2 border-b border-neutral-800 pb-2">
        <button
          onClick={() => setActiveTab('pixel')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
            activeTab === 'pixel'
              ? 'bg-neutral-800 text-white'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Code2 className="w-4 h-4 text-emerald-400" />
          <span>Método 1: Script de Píxel (Para el Frontend)</span>
        </button>

        <button
          onClick={() => setActiveTab('webhook')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
            activeTab === 'webhook'
              ? 'bg-neutral-800 text-white'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Webhook className="w-4 h-4 text-sky-400" />
          <span>Método 2: Webhook de Conversión (Para el Backend)</span>
        </button>
      </div>

      {/* Tab 1: Píxel de Seguimiento */}
      {activeTab === 'pixel' && (
        <div className="space-y-6">
          <div className="bg-[#161616] border border-neutral-800 rounded-xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Code2 className="w-4 h-4 text-emerald-400" />
                  <span>Script de Seguimiento Ligero (JavaScript)</span>
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Inserta este fragmento en tu página de bienvenida o confirmación tras el registro exitoso del usuario.
                </p>
              </div>

              <button
                onClick={() => handleCopy(pixelSnippet, 'pixel')}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-black bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors cursor-pointer shrink-0"
              >
                {copiedPixel ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedPixel ? '¡Copiado!' : 'Copiar Script'}</span>
              </button>
            </div>

            <div className="bg-black border border-neutral-800 rounded-lg p-4 font-mono text-xs text-neutral-300 overflow-x-auto">
              <pre>{pixelSnippet}</pre>
            </div>

            {/* Live Pixel Tester Button */}
            <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <div className="text-xs font-semibold text-white">¿Quieres probar el Píxel ahora mismo?</div>
                <div className="text-xs text-neutral-400">
                  Simula la visita a la página de agradecimiento y verifica cómo incrementa el contador.
                </div>
              </div>

              <button
                onClick={handleTestPixel}
                disabled={testingPixel}
                className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 hover:bg-emerald-500/20 rounded-md transition-colors cursor-pointer shrink-0"
              >
                <Play className="w-3 h-3" />
                <span>{testingPixel ? 'Disparando...' : 'Probar Píxel en Vivo'}</span>
              </button>
            </div>

            {pixelResult && (
              <div className="p-3 bg-neutral-900 border border-emerald-500/30 rounded-lg font-mono text-xs text-emerald-300">
                <span className="font-semibold">Respuesta del Píxel:</span> Registro exitoso. Registros acumulados: {pixelResult.currentRegistrations} / {pixelResult.targetRegistrations} (Estado: {pixelResult.status}).
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Webhook de Conversión */}
      {activeTab === 'webhook' && (
        <div className="space-y-6">
          <div className="bg-[#161616] border border-neutral-800 rounded-xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Webhook className="w-4 h-4 text-sky-400" />
                  <span>URL de Webhook de Conversión Única</span>
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Tu servidor puede emitir un HTTP POST a este endpoint cada vez que se cree un nuevo usuario.
                </p>
              </div>

              <button
                onClick={() => handleCopy(webhookUrl, 'webhook')}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-neutral-800 hover:bg-neutral-700 rounded-md border border-neutral-700 transition-colors cursor-pointer shrink-0"
              >
                {copiedWebhook ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedWebhook ? 'Copiado' : 'Copiar URL'}</span>
              </button>
            </div>

            <div className="bg-black border border-neutral-800 rounded-lg p-3 font-mono text-xs text-sky-400 flex items-center justify-between overflow-x-auto">
              <span>{webhookUrl}</span>
            </div>

            {/* Interactive Webhook Tester Form */}
            <form onSubmit={handleTestWebhook} className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
              <div className="text-xs font-semibold text-white flex items-center gap-2">
                <Play className="w-3.5 h-3.5 text-sky-400" />
                <span>Simulador de Envío de Webhook en Tiempo Real</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">Email del nuevo usuario:</label>
                  <input
                    type="email"
                    value={testEmail}
                    onChange={(e) => setTestEmail(e.target.value)}
                    required
                    className="w-full bg-black border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">Referente / Origen:</label>
                  <input
                    type="text"
                    value={testReferrer}
                    onChange={(e) => setTestReferrer(e.target.value)}
                    className="w-full bg-black border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-neutral-500 font-mono">
                  Se enviará POST con payload JSON al endpoint de KaSe
                </span>
                <button
                  type="submit"
                  disabled={testingWebhook}
                  className="px-4 py-1.5 text-xs font-medium text-black bg-sky-400 hover:bg-sky-300 rounded transition-colors cursor-pointer"
                >
                  {testingWebhook ? 'Procesando...' : 'Enviar POST de Prueba'}
                </button>
              </div>

              {webhookResult && (
                <div className="mt-3 p-3 bg-black border border-neutral-800 rounded text-xs font-mono">
                  <div className="text-emerald-400 font-semibold mb-1">HTTP 200 OK: Evento Registrado</div>
                  <pre className="text-neutral-300 text-[11px] overflow-x-auto">
                    {JSON.stringify(webhookResult, null, 2)}
                  </pre>
                </div>
              )}
            </form>

            {/* Code Examples */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span className="font-semibold text-white">Ejemplo con cURL</span>
                <button
                  onClick={() => handleCopy(curlSnippet, 'curl')}
                  className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer"
                >
                  {copiedCurl ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedCurl ? 'Copiado' : 'Copiar cURL'}</span>
                </button>
              </div>
              <div className="bg-black border border-neutral-800 rounded-lg p-3 font-mono text-[11px] text-neutral-300 overflow-x-auto">
                <pre>{curlSnippet}</pre>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
